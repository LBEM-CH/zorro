=====
Zorro Image Registration Software
=====

Author: Robert A. McLeod
Email: robert.mcleod@unibas.ch

Zorro is a package designed for registration of image drift for dose fractionation in electron microscopy.  It is specifically designed to suppress correlated noise.

It has the following dependencies:
* `numpy`
* `SciPy`
* `pyFFTW`

And the following optional dependencies:

* `PyTables`
* `scikit-image`

It comes packaged with a re-written version of the NumExpr virtual machine called `numexprz` that has support for `complex64` data types.  

Zorro also comes with a Skulk Manager package which may be used as a daemon to watch a directory for new image stacks and automatically process them.



Automator 
-----

The Automator for Zorro and 2dx is a GUI interface to Zorro and the Skulk Manager.

It has the following additional dependencies:
* `PySide`